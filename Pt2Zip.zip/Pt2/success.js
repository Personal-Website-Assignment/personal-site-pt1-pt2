setTimeout(() => {
    window.location.href = window.location.origin
  }, 5000)